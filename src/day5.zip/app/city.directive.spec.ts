import { CityDirective } from './city.directive';

describe('CityDirective', () => {
  it('should create an instance', () => {
    const directive = new CityDirective();
    expect(directive).toBeTruthy();
  });
});
